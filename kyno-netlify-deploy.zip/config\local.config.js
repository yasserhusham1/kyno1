﻿/** Optional overrides */
window.__BASMA_LOCAL_CONFIG__ = {

};

