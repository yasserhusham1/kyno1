/**
 * Supabase defaults — anon key is public (RLS protects data).
 * Overridden by config/local.config.js locally or Netlify env at build.
 */
window.__BASMA_SUPABASE_DEFAULTS__ = {
  supabaseUrl: 'https://pyxwpwbuwfrzqsnzhxip.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InB5eHdwd2J1d2ZyenFzbnpoeGlwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk4MTY1OTMsImV4cCI6MjA5NTM5MjU5M30.OP94hWzkAVaBbJin8zziBitKBB01qyrxmWBXOa5pj8k',
  appEnv: 'production'
};
