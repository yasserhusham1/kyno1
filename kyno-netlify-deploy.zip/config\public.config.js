/**
 * إعدادات عامة — لا تضع service_role أو أسرار هنا.
 * للإنتاج: أنشئ config/local.config.js من .env.example
 */
(function (global) {
  'use strict';

  var defaults = {
    supabaseUrl: '',
    supabaseAnonKey: '',
    appEnv: 'development',
    appVersion: '1.0.0',
    sentryDsn: '',
    strictRls: false,
    authUseCookies: true,
    kynoRpcMode: false,
    kynoFinalLockdown: false,
    realtimeTables: ['employees', 'employee_devices', 'attendance', 'app_settings', 'leaves'],
    pageSize: 100,
    maxUploadBytes: 2 * 1024 * 1024,
    allowedUploadMime: ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
  };

  var local = {};
  var supabaseDefaults = {};
  try {
    if (global.__BASMA_SUPABASE_DEFAULTS__) supabaseDefaults = global.__BASMA_SUPABASE_DEFAULTS__;
  } catch (e) { /* ignore */ }
  try {
    if (global.__BASMA_LOCAL_CONFIG__) local = global.__BASMA_LOCAL_CONFIG__;
  } catch (e) { /* ignore */ }

  var config = Object.assign({}, defaults, supabaseDefaults, local);

  // Hosted Supabase: direct table writes blocked by RLS (migration 033+) — always RPC
  var hostedUrl = String(config.supabaseUrl || '').replace(/\/$/, '');
  if (/\.supabase\.co$/i.test(hostedUrl)) {
    config.kynoRpcMode = true;
    config.kynoFinalLockdown = true;
  } else if (config.appEnv === 'production') {
    if (!Object.prototype.hasOwnProperty.call(local, 'kynoRpcMode')) config.kynoRpcMode = true;
    if (!Object.prototype.hasOwnProperty.call(local, 'kynoFinalLockdown')) config.kynoFinalLockdown = true;
  }

  global.BasmaConfig = Object.freeze({
    get: function (key) { return config[key]; },
    supabaseUrl: function () { return String(config.supabaseUrl || '').trim(); },
    supabaseAnonKey: function () { return String(config.supabaseAnonKey || '').trim(); },
    isProduction: function () { return config.appEnv === 'production'; },
    authUseCookies: function () { return config.authUseCookies !== false; },
    kynoRpcMode: function () { return config.kynoRpcMode === true; },
    kynoFinalLockdown: function () { return config.kynoFinalLockdown === true; },
    pageSize: function () { return Math.max(20, parseInt(config.pageSize, 10) || 100); },
    realtimeTables: function () { return Array.isArray(config.realtimeTables) ? config.realtimeTables.slice() : ['employees']; },
    maxUploadBytes: function () { return config.maxUploadBytes; },
    allowedUploadMime: function () { return config.allowedUploadMime.slice(); },
    appVersion: function () {
      if (global.BasmaApp && global.BasmaApp.version) return global.BasmaApp.version;
      return String(config.appVersion || '1.0.0');
    }
  });
})(typeof window !== 'undefined' ? window : globalThis);
